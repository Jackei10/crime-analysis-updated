a=input()
print(a)